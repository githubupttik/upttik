<h1><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('paidchat/expiredchat','Chat');?></h1>

<p><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('paidchat/expiredchat','Chat was closed.');?></p>