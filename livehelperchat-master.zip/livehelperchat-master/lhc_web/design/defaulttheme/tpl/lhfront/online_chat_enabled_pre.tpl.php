<?php 
	$online_chat_enabled_pre = true; 
	$online_visitors_enabled_pre = true; 
?>