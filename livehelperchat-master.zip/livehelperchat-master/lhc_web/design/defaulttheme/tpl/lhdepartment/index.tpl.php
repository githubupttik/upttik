<h1>Manage departments and their groups</h1>

<ul>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('department/departments')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('system/configuration','Departments');?></a></li>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('department/group')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('system/configuration','Departments groups');?></a></li>
</ul>