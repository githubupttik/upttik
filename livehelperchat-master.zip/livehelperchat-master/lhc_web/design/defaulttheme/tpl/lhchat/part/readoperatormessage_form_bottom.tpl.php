<?php 
/**
 * You can override this template and have custom bottom buttons or logic.
 * */
?>
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/readoperatormessage_form_bottom_content.tpl.php'));?>