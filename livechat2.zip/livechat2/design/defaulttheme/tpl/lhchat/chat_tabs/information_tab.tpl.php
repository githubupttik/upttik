<div role="tabpanel" class="tab-pane<?php if ($chatTabsOrderDefault == 'information_tab_tab') print ' active';?>" id="main-user-info-tab-<?php echo $chat->id?>">
    <?php include(erLhcoreClassDesign::designtpl('lhchat/chat_tabs/information_tab_user_info.tpl.php'));?>
</div>