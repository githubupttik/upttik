<?php 
/**
 * Override this template to have something above messages block in admin chat
 * */
?>