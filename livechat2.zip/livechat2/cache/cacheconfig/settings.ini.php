<?php
 return array (
  'settings' => 
  array (
    'cachetimestamps' => 
    array (
      'translationfile' => 0,
      'accessfile' => 1501293222,
    ),
  ),
  'comments' => NULL,
);
?>