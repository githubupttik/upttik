<?php
 return array (
  'new' => 
  array (
    'script' => 'new.php',
    'functions' => 
    array (
      0 => 'use',
    ),
    'params' => 
    array (
      0 => 'identifier',
    ),
    'script_path' => 'modules/lhabstract/new.php',
  ),
  'list' => 
  array (
    'script' => 'list.php',
    'functions' => 
    array (
      0 => 'use',
    ),
    'params' => 
    array (
      0 => 'identifier',
    ),
    'uparams' => 
    array (
      0 => 'name',
    ),
    'script_path' => 'modules/lhabstract/list.php',
  ),
  'downloadbinnary' => 
  array (
    'script' => 'downloadbinnary.php',
    'functions' => 
    array (
      0 => 'use',
    ),
    'params' => 
    array (
      0 => 'identifier',
      1 => 'object_id',
    ),
    'script_path' => 'modules/lhabstract/downloadbinnary.php',
  ),
  'edit' => 
  array (
    'script' => 'edit.php',
    'functions' => 
    array (
      0 => 'use',
    ),
    'params' => 
    array (
      0 => 'identifier',
      1 => 'object_id',
    ),
    'script_path' => 'modules/lhabstract/edit.php',
  ),
  'delete' => 
  array (
    'script' => 'delete.php',
    'functions' => 
    array (
      0 => 'use',
    ),
    'params' => 
    array (
      0 => 'identifier',
      1 => 'object_id',
    ),
    'uparams' => 
    array (
      0 => 'csfr',
    ),
    'script_path' => 'modules/lhabstract/delete.php',
  ),
  'index' => 
  array (
    'script' => 'index.php',
    'functions' => 
    array (
      0 => 'use',
    ),
    'params' => 
    array (
    ),
    'script_path' => 'modules/lhabstract/index.php',
  ),
);
?>