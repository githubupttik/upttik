<?php
 return array (
  'list' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'manage_faq',
    ),
    'script_path' => 'modules/lhfaq/list.php',
  ),
  'delete' => 
  array (
    'params' => 
    array (
      0 => 'id',
    ),
    'uparams' => 
    array (
      0 => 'csfr',
    ),
    'functions' => 
    array (
      0 => 'manage_faq',
    ),
    'script_path' => 'modules/lhfaq/delete.php',
  ),
  'view' => 
  array (
    'params' => 
    array (
      0 => 'id',
    ),
    'functions' => 
    array (
      0 => 'manage_faq',
    ),
    'script_path' => 'modules/lhfaq/view.php',
  ),
  'new' => 
  array (
    'params' => 
    array (
      0 => 'id',
    ),
    'functions' => 
    array (
      0 => 'manage_faq',
    ),
    'script_path' => 'modules/lhfaq/new.php',
  ),
  'faqwidget' => 
  array (
    'params' => 
    array (
    ),
    'uparams' => 
    array (
      0 => 'theme',
      1 => 'url',
      2 => 'mode',
      3 => 'identifier',
    ),
    'script_path' => 'modules/lhfaq/faqwidget.php',
  ),
  'getstatus' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
    ),
    'uparams' => 
    array (
      0 => 'theme',
      1 => 'noresponse',
      2 => 'position',
      3 => 'top',
      4 => 'units',
    ),
    'script_path' => 'modules/lhfaq/getstatus.php',
  ),
  'embed' => 
  array (
    'params' => 
    array (
    ),
    'uparams' => 
    array (
      0 => 'theme',
    ),
    'functions' => 
    array (
    ),
    'script_path' => 'modules/lhfaq/embed.php',
  ),
  'embedcode' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'manage_faq',
    ),
    'script_path' => 'modules/lhfaq/embedcode.php',
  ),
  'htmlcode' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'manage_faq',
    ),
    'script_path' => 'modules/lhfaq/htmlcode.php',
  ),
);
?>