<?php
 return array (
  'export' => 
  array (
    'params' => 
    array (
      0 => 'theme',
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/export.php',
  ),
  'import' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/import.php',
  ),
  'index' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/index.php',
  ),
  'default' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/default.php',
  ),
  'defaultadmintheme' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/defaultadmintheme.php',
  ),
  'adminthemes' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/adminthemes.php',
  ),
  'adminnewtheme' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/adminnewtheme.php',
  ),
  'adminthemedelete' => 
  array (
    'params' => 
    array (
      0 => 'id',
    ),
    'uparams' => 
    array (
      0 => 'csfr',
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/adminthemedelete.php',
  ),
  'adminthemeedit' => 
  array (
    'params' => 
    array (
      0 => 'id',
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/adminthemeedit.php',
  ),
  'deleteresource' => 
  array (
    'params' => 
    array (
      0 => 'id',
      1 => 'context',
      2 => 'hash',
    ),
    'functions' => 
    array (
      0 => 'administratethemes',
    ),
    'script_path' => 'modules/lhtheme/deleteresource.php',
  ),
  'gethash' => 
  array (
    'params' => 
    array (
    ),
    'script_path' => 'modules/lhtheme/gethash.php',
  ),
);
?>