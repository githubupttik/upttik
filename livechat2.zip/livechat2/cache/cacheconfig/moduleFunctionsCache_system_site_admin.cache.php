<?php
 return array (
  'htmlcode' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'generatejs',
    ),
    'script_path' => 'modules/lhsystem/htmlcode.php',
  ),
  'embedcode' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'generatejs',
    ),
    'script_path' => 'modules/lhsystem/embedcode.php',
  ),
  'configuration' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'use',
    ),
    'script_path' => 'modules/lhsystem/configuration.php',
  ),
  'expirecache' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'expirecache',
    ),
    'script_path' => 'modules/lhsystem/expirecache.php',
  ),
  'smtp' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'configuresmtp',
    ),
    'script_path' => 'modules/lhsystem/smtp.php',
  ),
  'timezone' => 
  array (
    'params' => 
    array (
    ),
    'functions' => 
    array (
      0 => 'timezone',
    ),
    'script_path' => 'modules/lhsystem/timezone.php',
  ),
  'languages' => 
  array (
    'params' => 
    array (
    ),
    'uparams' => 
    array (
      0 => 'updated',
      1 => 'sa',
    ),
    'functions' => 
    array (
      0 => 'changelanguage',
    ),
    'script_path' => 'modules/lhsystem/languages.php',
  ),
  'update' => 
  array (
    'params' => 
    array (
    ),
    'uparams' => 
    array (
      0 => 'action',
    ),
    'functions' => 
    array (
      0 => 'performupdate',
    ),
    'script_path' => 'modules/lhsystem/update.php',
  ),
  'autodbupdate' => 
  array (
    'params' => 
    array (
      0 => 'hash',
    ),
    'uparams' => 
    array (
    ),
    'script_path' => 'modules/lhsystem/autodbupdate.php',
  ),
);
?>